# Piano Practice Studio

**Tiếng Việt** · [English](#english)

Luyện piano với sheet nhạc tương tác, bài tập có hướng dẫn, đọc nhạc mỗi ngày và chấm điểm bằng micro. Chạy ngay trên trình duyệt, cài được như ứng dụng và luyện được khi không có mạng. Giao diện và nội dung bài có tiếng Việt và tiếng Anh: bấm **EN** / **VI** ở góc trên bên phải để đổi.

## Bắt đầu

1. Mở **Khóa học** và chọn một bài, hoặc mở **Hôm nay** để tiếp tục bài đang tập.
2. Chọn **Tay phải**, **Tay trái** hoặc **Hai tay**.
3. Nghe mẫu, rồi chọn chế độ luyện và bắt đầu chơi.
4. Chỉnh tốc độ và đoạn luyện cho vừa sức.

Khi đang tập, mục bạn mở bài từ đó vẫn sáng trên thanh điều hướng, và nút quay lại ở đầu trang đưa bạn về đúng mục đó.

## Mục tiêu tuần và buổi tập nhanh

Trang **Hôm nay** có thẻ **Mục tiêu tuần**:

- **Đặt mục tiêu:** chọn số ngày mỗi tuần (3, 4, 5 hoặc 7) và số phút mỗi ngày (5, 10, 15 hoặc 20). Một ngày nghỉ không làm mất gì; chỉ cần đủ số ngày trong tuần.
- **Theo dõi tiến độ:** bảy ô ngày trong tuần đổi màu khi ngày đó đủ số phút; thanh "Hôm nay" cho biết bạn đã tập bao lâu. App chỉ tính thời gian khi bạn ở màn luyện tập và đang chơi, nghe mẫu hoặc vừa thao tác.
- **Tập nhanh:** **▶ Tập 10 phút ngay** xếp sẵn một buổi ngắn: ôn một bài đến hạn, tập bài đang dở, rồi một bài Đọc nhạc. Thanh màu vàng ở đầu màn luyện tập cho biết bước hiện tại, thời gian, và nút **Bước tiếp**.
- **Ôn bài:** mỗi bài hoàn thành được nhắc ôn sau 1, 3, 7, 21 và 60 ngày, trong mục **Cần ôn hôm nay**.
- **Khi bị kẹt:** nếu ba lượt chấm điểm liền chưa ổn, hoặc sau 6 lượt hay 15 phút tập một bài mà chưa nhận sao mới, thẻ **Thử một cách dễ hơn** hiện trong màn luyện tập: chậm lại 8 BPM, tập riêng một tay, tập nửa đoạn, ôn một bài nền dễ hơn cùng kỹ năng, hoặc nghỉ rồi quay lại.
- **Nhắc tập:** trong thẻ Mục tiêu tuần, mục **🔔 Nhắc tôi tập qua lịch** tạo một file lịch (.ics) lặp lại vào các ngày và giờ bạn chọn; mở file để thêm vào Lịch của điện thoại hoặc máy tính. Lịch nhắc kể cả khi không mở app. Khi đã cài app, biểu tượng app hiện số 1 cho đến khi hôm nay tập đủ số phút (trên trình duyệt hỗ trợ). Quay lại sau vài ngày nghỉ, app gợi ý bắt đầu nhẹ nhàng bằng một bài ôn.
- **Chia sẻ:** nút **↗ Chia sẻ tuần này** ở trang Tiến độ tạo ảnh tóm tắt tuần (số ngày, số phút, số tuần liền, tốc độ tăng nhiều nhất) để gửi qua ứng dụng khác, hoặc tải ảnh về.
- **Tiến độ:** mục **Tiến độ** trên thanh điều hướng cho thấy tổng thời gian luyện, số ngày đã tập, số tuần liền đạt mục tiêu, lịch luyện tập 12 tuần, số phút mỗi tuần, tốc độ đã tăng ở từng bài và các cột mốc.

## Chế độ luyện

- **Nghe mẫu:** nghe đàn mẫu và nhìn sheet được tô theo vị trí đang phát.
- **Tập từng nốt:** bật micro và cho phép truy cập. Sheet chờ đến khi bạn đánh đúng nốt cần đánh. Hợp âm được chấm theo đáp án đã biết của bài.
- **Chơi theo nhịp:** sheet chạy theo tốc độ đã chọn. Có thể chơi không cần micro, hoặc bật **Chấm bằng micro** để chấm cả nốt đơn, hợp âm và hai tay.
- **Nghe hợp âm:** chế độ thử nghiệm, hiển thị những gì micro nghe được, không chấm điểm.

Khi dùng micro, nên tập ở phòng yên tĩnh và đeo tai nghe khi nghe mẫu. Âm không đủ rõ sẽ được để trống thay vì chấm sai. Một số hợp âm, âm vực và kỹ thuật cần bạn tự đánh giá; khi đó app hiện nút **Đã đánh · Tiếp**.

### Đọc màu trên sheet

| Màu | Ý nghĩa |
|---|---|
| Tím | Nốt tay phải |
| Hồng | Nốt tay trái |
| Cam | Nốt cần đánh lúc này |
| Xanh đặc | Đúng |
| Viền xanh, ruột trắng | Đúng tên nốt nhưng lệch quãng tám |
| Đỏ sẫm | Sai |
| Đỏ sẫm nhạt, viền đứt | Bỏ sót |

Chú thích màu hiện ngay dưới sheet khi đang chấm điểm. Tên đoạn và hợp âm nằm phía trên khuông; sắc thái (*p*, *mf*…) và chữ diễn cảm nằm dưới khuông của tay tương ứng.

### Điểm và combo

Khi luyện có micro chấm (**Tập từng nốt**, hoặc **Chơi theo nhịp** có bật chấm bằng micro), mỗi lượt có điểm như game âm nhạc:

- **Điểm mỗi nốt:** đúng nốt 100 điểm (chơi theo nhịp mà hơi sớm hoặc muộn: 70); đúng tên nhưng lệch quãng tám 50; sai hoặc bỏ sót 0.
- **Combo:** đúng liên tiếp 8 nốt thì điểm ×2, 16 nốt ×3, 32 nốt ×4. Sai hoặc bỏ sót thì combo về 0. Micro nghe không rõ thì không tính sai và không làm mất combo.
- **Thưởng cuối lượt:** không lỗi +20%, đạt tempo của bài +10%, lượt đầu tiên trong ngày ×1,5.
- **Hạng theo độ chính xác:** S (≥ 98% và đạt tempo), A (≥ 90%), B (≥ 75%), C.
- **Kỷ lục:** mỗi bài lưu điểm cao nhất của bạn; trang **Tiến độ** có mục **Kỷ lục điểm** (số lần đạt từng hạng và các bài điểm cao nhất). Lượt hạng C được tính là lượt khó: app gợi ý chậm lại, tập riêng một tay hoặc đoạn ngắn hơn.
- **Màn hình:** góc trên sheet hiện tổng điểm, hệ số và combo; cuối lượt có bảng tổng kết. Không có âm thanh; nếu máy bật giảm chuyển động thì chỉ đổi màu.

### Nốt vàng và phần thưởng

- **Nốt vàng 🪙:** mỗi lượt có micro chấm cho 1 nốt vàng mỗi 100 điểm, thêm 20 khi đạt hạng S và 10 khi đạt A.
- **Cửa hàng** (trang **Tiến độ** → **Nốt vàng & phần thưởng**): đổi nốt vàng lấy giao diện bàn phím (Gỗ ấm, Đêm xanh, Kem sữa, Neon), màu nốt trên sheet (Đại dương, Quả mọng, Mực), hiệu ứng phím (Mưa sao, Tuyết, Cánh hoa, Pháo hoa combo: hạt sáng rơi xuống phím đang vang, dày hơn khi combo cao; tự tắt khi máy bật giảm chuyển động) và tiếng nhịp gõ (Mõ gỗ, Nhẹ nhàng, Chuông; bấm ▶ để nghe thử). Màu chấm đúng, sai và nốt cần đánh không đổi.
- **Rương tuần:** mỗi tuần đạt mục tiêu mở được một rương, chứa một món chưa có hoặc nốt vàng.
- **Danh hiệu:** Chuỗi 32, Thợ săn hạng S, Nhịp chuẩn, Tay trái vững, Kiên trì 4 tuần, Người đọc nhạc, 100 lượt có điểm. Danh hiệu đã chọn hiện ở trang Tiến độ và trên ảnh chia sẻ.
- Mọi bài học luôn mở; phần thưởng chỉ để trang trí.

## Hiệu chỉnh theo đàn của bạn

Trong phần micro, mở **Hiệu chỉnh với đàn thật** để đo tiếng ồn phòng, độ lên dây (A4) và thử vài nốt, hợp âm. Kết quả được lưu và dùng cho mọi bài. Với từng bài, bạn có thể chọn **Thu phím cho bài này** để thu các phím của bài trên đàn của mình để app nhận diện chính xác hơn.

## Cài ứng dụng và luyện offline

Bấm nút **⬇ Cài app** ở góc trên bên phải, có ở mọi màn hình. Trên Chrome, Edge và Android, hộp cài đặt của trình duyệt hiện ngay. Trên iPhone/iPad, bảng hướng dẫn hiện ra: bấm Chia sẻ rồi chọn “Thêm vào Màn hình chính”. Ứng dụng đã cài mở trong cửa sổ riêng; lần mở đầu từ màn hình chính, app đề nghị tải bộ đàn để luyện offline. Sau khi cài, nút đổi thành **☁ Offline** (tải âm, cập nhật) và thành **↻ Cập nhật** khi có bản mới.

Đợi thông báo sẵn sàng offline rồi mới ngắt mạng. Bài tập và bộ đàn gọn được lưu tự động. Âm đàn web được lưu dần khi bạn dùng; chọn **Tải âm để luyện offline** để tải trọn bộ. Giữ app mở trong lúc tải; có thể hủy và tải tiếp sau. Thiết bị có thể tự xóa bộ nhớ trình duyệt, nên hãy kiểm tra lại trước khi luyện không có mạng.

Khi có phiên bản mới, chọn **Cập nhật ứng dụng** sau khi tập xong lượt đang chơi. Cập nhật giữ nguyên tiến độ và cài đặt. Nếu một tab khác đang tập, hãy xong lượt đó trước.

## Dùng trên điện thoại

Thanh điều hướng dưới cùng có Khóa học, Đọc nhạc, Kỹ năng và Hôm nay. Nút phát luôn trong tầm tay khi cuộn. Chọn chế độ và tay, rồi bấm **Tập trung** để dành chỗ cho sheet và bàn phím. Chế độ Tập trung xin toàn màn hình và xoay ngang trên điện thoại hỗ trợ; nếu không tự xoay được, hãy xoay máy bằng tay. Khi xoay ngang, các nút điều khiển nằm cạnh sheet: bấm **Ẩn điều khiển** để mở rộng sheet, **Hiện điều khiển** để hiện lại. Thoát Tập trung để đổi cách luyện.

## Sheet nhạc và phát nhạc

- Đổi **Tốc độ** để tập chậm hoặc nhanh hơn.
- Chọn ô nhịp bắt đầu và kết thúc để tập một đoạn ngắn.
- Mở **Vị trí tay & cách chạm phím → Số ngón & chuyển vị trí** để xem phím/ngón đầu đoạn và mốc luồn, vắt ngón hoặc dịch tay. Hướng dẫn cập nhật theo tay/đoạn đang chọn; lời nhắc dưới sheet đi theo vị trí luyện. 1 cái, 2 trỏ, 3 giữa, 4 áp út, 5 út; → âm cao, ← âm trầm.
- Bật **Lặp đoạn** để lặp lại đoạn đó.
- Bấm **Tập lại** để về đầu đoạn đã chọn.
- Bật **Nhịp gõ** để giữ nhịp đều.
- Hiện hoặc ẩn bàn phím trên màn hình.
- **Nốt rơi trên bàn phím** (trong Hiển thị & chuyển động, tắt sẵn): các vạch màu rơi xuống đúng phím theo tốc độ, dài ngắn theo trường độ. Chỉ có ở Nghe mẫu và Chơi theo nhịp, không có ở Đọc nhạc mỗi ngày; sheet vẫn hiện, và vạch mờ đi khi bài đã đủ 3 sao để bạn quay lại đọc sheet.
- Bấm **Tập trung** để phóng to vùng luyện, dùng nút trước/sau để chuyển bài.

Phím tắt: Space để bắt đầu hoặc dừng, Esc để thoát Tập trung.

## Đọc nhạc mỗi ngày

Mở **Đọc nhạc mỗi ngày** để có một buổi luyện xoay vòng qua 10 nhóm kỹ năng, gồm 252 dạng bài và 1.008 biến thể.

Làm theo mục tiêu của từng bài, chơi trên đàn, rồi chọn **Ổn** hoặc **Cần luyện lại**. Có thể bỏ qua một bài, hoặc lưu buổi tập để làm tiếp sau. Bài đọc thị tấu giới hạn số lần đọc lại để bạn quen đọc nhạc mới.

## Kỹ năng

Mở **Kỹ năng** để xem mục tiêu học, kỹ năng cần có trước và các bài liên quan. Dùng sơ đồ để thấy kỹ năng đã luyện và chọn phần tập tiếp.

## Âm đàn

Mở phần cài đặt âm thanh để chọn bộ đàn. Bản web dùng mẫu thu Salamander Grand Piano (30 phím thu thật, 8 mức lực) và chỉ tải các nốt mà bài đang mở cần đến.

## Tiến độ, quyền riêng tư và thống kê

- Tiến độ, hiệu chỉnh và các phím đã thu chỉ lưu trong trình duyệt bạn đang dùng. Mỗi trình duyệt, mỗi thiết bị có tiến độ riêng; xóa dữ liệu trình duyệt có thể làm mất tiến độ. Người dùng khác nhau không ảnh hưởng đến nhau.
- Âm thanh micro được xử lý ngay trên thiết bị, không gửi lên máy chủ nào.
- Trang có **thống kê ẩn danh** bằng Google Analytics, chỉ chạy khi bạn chọn **Đồng ý** ở lần mở đầu tiên; đổi lựa chọn bất cứ lúc nào ở cuối trang **Hôm nay**. Thống kê ghi bài được mở, chế độ luyện, lượt tập xong, sao đạt được, quyền micro, buổi Đọc nhạc, việc cài app và lỗi của app, để biết bài nào khó và chế độ nào hữu ích. Không gửi âm thanh micro, nốt bạn chơi hay thông tin cá nhân; tắt tín hiệu quảng cáo và Google Signals. Khi không có mạng, thống kê không chạy và app vẫn hoạt động bình thường.

Hãy tự đánh giá thế bấm ngón, tư thế, cách nhấn phím và những kỹ thuật mà nhận diện âm thanh chưa đánh giá đáng tin được.

---

<a id="english"></a>

# Piano Practice Studio (English)

[Tiếng Việt](#piano-practice-studio) · **English**

Practise piano with interactive sheet music, guided exercises, daily reading sessions and microphone-assisted feedback. It runs in the browser, installs as an app and works offline.

The app is available in English: press **EN** at the top right, or open it with `?lang=en` at the end of the address (for example `…/piano-practice-studio/?lang=en`). The choice is remembered in your browser. The Vietnamese names in bold below are the labels of the Vietnamese interface; in English they appear as the names in brackets.

## Get started

1. Open **Khóa học** (Courses) and choose a lesson, or open **Hôm nay** (Today) to return to your current exercise.
2. Select **Tay phải** (Right hand), **Tay trái** (Left hand) or **Hai tay** (Both hands).
3. Listen to the example, then choose a practice mode and start playing.
4. Adjust the tempo and practice range to a comfortable level.

While you practise, the section you opened the lesson from stays highlighted in the navigation, and the back button at the top returns you there.

## Weekly goal and quick sessions

The **Hôm nay** (Today) screen has a **Mục tiêu tuần** (Weekly goal) card:

- **Set a goal:** choose days per week (3, 4, 5 or 7) and minutes per day (5, 10, 15 or 20). A day off costs nothing; just reach the number of days in the week.
- **Track progress:** the seven day circles change colour when a day reaches its minutes, and the "Today" bar shows how long you've practised. Time counts only on the practice screen while you play, listen or have just used the page.
- **Quick session:** **▶ Tập 10 phút ngay** (Practise 10 minutes now) lines up a short session: one review that is due, your current lesson, then one Daily Reading exercise. A yellow bar at the top of the practice screen shows the step, the time and a **Bước tiếp** (Next step) button.
- **Reviews:** each completed lesson comes back for review after 1, 3, 7, 21 and 60 days, under **Cần ôn hôm nay** (Due for review today).
- **When you're stuck:** after three graded rounds in a row that didn't go well, or 6 rounds or 15 minutes on a lesson without a new star, a **Thử một cách dễ hơn** (Try an easier way) card appears in the practice screen: slow down by 8 BPM, practise one hand, practise half the passage, review an easier foundation lesson for the same skill, or take a break.
- **Reminders:** in the weekly goal card, **🔔 Nhắc tôi tập qua lịch** (Remind me through my calendar) creates a repeating calendar file (.ics) on the days and time you choose; open it to add it to your phone or computer calendar, which reminds you even when the app isn't open. When the app is installed, its icon shows a 1 until today's minutes are reached (in browsers that support it). Coming back after a few days off, the app suggests starting gently with a review.
- **Sharing:** **↗ Chia sẻ tuần này** (Share this week) on the Progress screen makes an image of your week (days, minutes, weeks in a row, biggest tempo gain) to send through another app, or to download.
- **Progress:** **Tiến độ** (Progress) in the navigation shows total practice time, days practised, weeks in a row on goal, a 12-week practice calendar, minutes per week, tempo gains per lesson and milestones.

## Practice modes

- **Nghe mẫu** (Listen): hear the example while the sheet highlights the current position.
- **Tập từng nốt** (Note by note): turn on the microphone and allow access. The sheet waits until you play the required notes. Chords are checked against the exercise's known answer.
- **Chơi theo nhịp** (Play in time): the sheet moves at your selected tempo. Play without a microphone, or turn on **Chấm bằng micro** (Score with microphone) to grade single notes, chords and both hands.
- **Nghe hợp âm** (Chord listening): experimental; shows what the microphone hears, without grading.

For microphone practice, use a quiet room and headphones when listening to examples. Input that is not clear enough stays ungraded instead of being marked wrong. Some chords, ranges and techniques need self-assessment; the app then shows **Đã đánh · Tiếp** (Played · Next).

### Reading the colours on the sheet

| Colour | Meaning |
|---|---|
| Violet | Right-hand note |
| Pink | Left-hand note |
| Amber | Note to play now |
| Solid green | Correct |
| Green outline, white fill | Right note name, wrong octave |
| Dark red | Wrong |
| Faded dark red, dashed outline | Missed |

A colour legend appears under the sheet while grading is on. Section names and chords sit above the staff; dynamics (*p*, *mf*…) and expression words sit under the staff of their hand.

### Score and combo

When the microphone grades a round (**Tập từng nốt** / Note by note, or **Chơi theo nhịp** / Play in time with microphone scoring), it scores like a rhythm game:

- **Points per note:** right note 100 (in play-in-time, slightly early or late: 70); right name in another octave 50; wrong or missed 0.
- **Combo:** 8 right notes in a row double the points, 16 triple them, 32 quadruple them. A wrong or missed note resets the combo; sounds the microphone can't make out never count as wrong and never break it.
- **Round bonuses:** no mistakes +20%, at the lesson's tempo +10%, first round of the day ×1.5.
- **Grade by accuracy:** S (≥ 98% and at tempo), A (≥ 90%), B (≥ 75%), C.
- **Personal best:** each lesson keeps your best score; the **Tiến độ** (Progress) screen has **Kỷ lục điểm** (Score records) with your grade counts and top lessons. A grade-C round counts as a hard round: the app suggests slowing down, one hand or a shorter passage.
- **On screen:** the total, multiplier and combo sit in the corner of the sheet, with a summary at the end of the round. No sound; with reduced motion, only colours change.

### Gold notes and rewards

- **Gold notes 🪙:** every microphone-graded round gives 1 gold note per 100 points, plus 20 for grade S and 10 for grade A.
- **Shop** (**Tiến độ** / Progress → **Nốt vàng & phần thưởng** / Gold notes & rewards): spend gold notes on keyboard skins (Warm wood, Blue night, Cream, Neon), note colours on the sheet (Ocean, Berry, Ink), key effects (Star rain, Snow, Petals, Combo fireworks: particles falling onto the keys that sound, richer at higher combos; off with reduced motion) and metronome sounds (Woodblock, Soft, Bell; press ▶ to preview). The grading colours and the note-to-play colour never change.
- **Weekly chest:** each week you meet your goal opens a chest with an item you don't have yet, or gold notes.
- **Titles:** Run of 32, S-grade hunter, Steady timing, Strong left hand, Four steady weeks, Music reader, 100 scored rounds. Your chosen title shows on the Progress screen and on the share image.
- Every lesson is always open; rewards are cosmetic only.

## Calibrate for your piano

In the microphone settings, open **Hiệu chỉnh với đàn thật** (Calibrate with a real piano) to measure room noise and tuning (A4), and to test a few notes and chords. The result is saved and used in every exercise. For individual exercises, choose **Thu phím cho bài này** (Record keys for this exercise) to record its keys on your own piano so the app recognises them more accurately.

## Install and practise offline

Press **⬇ Cài app** (Install app) at the top right, on every screen. In Chrome, Edge and Android the browser's install prompt opens straight away. On iPhone/iPad a short guide appears: tap Share, then “Add to Home Screen”. The installed app opens in its own window; the first time you open it from the home screen, it offers to download the piano for offline practice. Once installed, the button becomes **☁ Offline** (sounds, updates) and **↻ Cập nhật** (Update) when a new version is available.

Wait for the offline-ready message before disconnecting. Lessons and the compact piano bank are saved automatically. Web piano samples are saved as you use them; choose **Tải âm để luyện offline** (Download sounds for offline) to download the complete web bank. Keep the app open while downloading; you can cancel and resume later. The device may clear browser storage, so check availability before practising without a connection.

When a new version is available, use **Cập nhật ứng dụng** (Update app) after your practice round. Updates keep your progress and settings. If another tab is practising, finish that round first.

## Using a phone

The bottom navigation has Courses, Daily Reading, Skills and Today. Playback controls stay within reach while you scroll. Choose your mode and hand, then enter **Tập trung** (Focus) to give more space to the sheet and keyboard. Focus requests fullscreen and landscape on supported phones; if the screen does not rotate, turn your phone manually. In landscape the controls sit beside the sheet: tap **Ẩn điều khiển** (Hide controls) to widen the sheet and **Hiện điều khiển** (Show controls) to bring them back. Exit Focus to change the practice setup.

## Sheet music and playback

- Change **Tốc độ** (Tempo) to slow down or speed up.
- Select a starting and ending bar to work on a short passage.
- Open **Hand position & touch → Fingering & hand shifts** for the segment’s starting keys and thumb crossings or hand shifts. Guidance follows your chosen hand and passage; the cue below the sheet follows the practice position. 1 thumb, 2 index, 3 middle, 4 ring, 5 little finger; → higher, ← lower.
- Turn on **Lặp đoạn** (Loop) to repeat that passage.
- Use **Tập lại** (Replay) to return to the start of the passage.
- Turn on **Nhịp gõ** (Metronome) for a steady beat.
- Show or hide the on-screen keyboard.
- **Nốt rơi trên bàn phím** (Falling notes, under Display & motion, off by default): coloured bars fall onto the right keys at your tempo, as long as each note lasts. Only in Listen and Play in time, never in Daily Reading; the sheet stays on screen, and the bars fade once a lesson has 3 stars so you go back to reading.
- Enter **Tập trung** (Focus) for a larger view, and use the previous/next buttons to move between exercises.

Shortcuts: Space starts or stops, Esc leaves Focus.

## Daily reading

Open **Đọc nhạc mỗi ngày** (Daily Reading) for a rotating session across 10 skill areas, with 252 exercise families and 1,008 variations.

Follow each exercise's goal, play it on your piano, and select **Ổn** (Done) or **Cần luyện lại** (Needs review). You can skip an exercise, or save the session and resume later. Sight-reading exercises limit repeat readings so you keep moving on to fresh music.

## Skills

Open **Kỹ năng** (Skills) to see learning goals, prerequisites and related lessons. Use the graph to find skills you have practised and choose what to work on next.

## Piano sound

Open the sound settings to choose a piano. The web version uses Salamander Grand Piano samples (30 recorded keys, 8 velocity layers) and loads only the notes the open exercise needs.

## Progress, privacy and analytics

- Progress, calibration and recorded keys are stored only in the browser you are using. Each browser and device keeps its own progress; clearing browser data may remove it. Different learners do not affect each other.
- Microphone audio is processed on your device and is never sent to a server.
- The site has **anonymous usage statistics** through Google Analytics, active only if you choose **Đồng ý** (Agree) on your first visit; change your choice at any time at the bottom of **Hôm nay** (Today). It records which lessons are opened, practice modes, completed rounds, stars earned, microphone permission, reading sessions, app installs and app errors, to learn which lessons are hard and which modes help. It never sends microphone audio, the notes you play or personal information; advertising signals and Google Signals are off. Offline, statistics do not run and the app works as usual.

Use your own judgement for fingering, posture, touch and other techniques that audio recognition cannot yet assess reliably.
